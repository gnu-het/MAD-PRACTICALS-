# MADPractical5_21012022022

AIM: What is Service? Write down types of Service. Create an MP3 player application by using service by following below instructions.



Study: Service, Types of Service, Drawable Icon Add in project, MediaPlayer, Add Raw folder, Add mp3 song in raw folder

Create MainActivity and design according to shown in below image. Use Material 3 design

Create Service Class and implement MediaPlayer Object


Resources:


![image](https://user-images.githubusercontent.com/110646988/191333461-242138d6-a32a-4f0f-8c7d-9f4c2f9ac666.png)

![image](https://user-images.githubusercontent.com/110646988/191333423-57c609d5-7c92-43ee-9f0f-56e349d25033.png)




Output:

![Screenshot_20220920_222025](https://user-images.githubusercontent.com/110646988/191332089-52660fa1-222b-4760-8618-0530931a7ce5.png)


![Screenshot_20220920_222059](https://user-images.githubusercontent.com/110646988/191332109-6b40b949-1fc2-4ed8-87b7-20c120791387.png)


![Screenshot_20220920_222106](https://user-images.githubusercontent.com/110646988/191332124-66ada7fe-2be9-462c-bdd9-e2b2193b8de8.png)
