# MADPractical8_21012022022

Study: ImageView, Frame by Frame Animation, Twin Animation, Immersive Mode, Display Edge to Edge, SplashScreen, AnimationDrawable, onWindowFocusChanged() Method, AnimationUtils class, loadAnimation() method, setAnimationListener() method, overridePendingTransition() method, finish() method, anim folder in res, convert SVG file to .xml file

AIM: What is Frame by Frame Animation? What is Twin Animation? How can you achieve edge-to-edge content display in your app?  Create Android Application to demonstrate Frame by frame animation and splash screen to demonstrate twin animation according to below instructions.

1. Create MainActivity according to below UI design.

2. Create SplashActivity according to Video

3. Create gradient Rectangle by using <gradient> tag in <shape> tag for background of SplashActivity. Use radial rectangle with x = 0.9, y =0.9, radius = 1500. Start Color pink and End Color blue. shape should be rectangle

4. Add these all in project: <animation-list>, oneShot attribute, <set> tag, android:startOffset = 100, android:duration=1000, <scale> tag, <translate> tag, <rotate> tag, <alpha> tag

![1](https://user-images.githubusercontent.com/110646988/197452490-e4717472-4163-4967-a205-ac57674f6a74.png)


![2](https://user-images.githubusercontent.com/110646988/197452502-7a65d9c6-159b-4a31-8522-4c8ed171b8ac.png)
